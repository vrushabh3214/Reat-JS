import './App.css'
import Home from './page/Home'

function App() {

  return (
    <>
     <Home></Home>
    </>
  )
}

export default App
